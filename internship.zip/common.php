<?php
$servername="localhost";
$username="root";
$passworddb="";
$dbname="internship";
$con = mysqli_connect($servername,$username, $passworddb, $dbname);
?>